(function($){
	'use strict';

	//code starts here
	$('.menu-icon').on('click',function(){
		$('.strict-menu').slideToggle();
	});

	$(window).resize(function(){
		var screenSize=$(window).width();
		if(screenSize>768){
			$('.strict-menu').removeAttr('style')
		}
	});
	//menu end

	//scroll
	$(window).scroll(function(){
		var distance=$(window).scrollTop();
		$('.ojotha').text(distance);
		/*ojotha is not required anymore, it was wroiten to 
		make you undertand the scroll factors*/

		if(distance>1000){
			$('.to-top').fadeIn(1000);			
		}
		else{
			$('.to-top').fadeOut(1000);
		}
	});

	$('.to-top').on('click',function(){
		$('html').animate({'scrollTop':0},2000);
	});
	

}) (jQuery);